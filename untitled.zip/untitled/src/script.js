let demoLogs = [];

function processData() {
    const method = document.getElementById("method").value;
    const data = document.getElementById("inputData").value;
    const btn = document.getElementById("enterBtn");

    if (!method || !data) {
        alert("Please fill all fields.");
        return;
    }

    btn.classList.add("loading");
    btn.innerHTML = '<div class="loader"></div>';

    setTimeout(() => {
        demoLogs.push({
            method: method,
            value: data,
            time: new Date().toLocaleTimeString()
        });

        btn.classList.remove("loading");
        btn.innerHTML = "ENTER";
        document.getElementById("inputData").value = "";

        alert("Demo process completed.");
    }, 2000);
}

function adminLogin() {
    const user = document.getElementById("adminUser").value;
    const pass = document.getElementById("adminPass").value;

    if (user === "Admin" && pass === "20102108") {
        document.getElementById("dashboard").classList.remove("hidden");
        renderLogs();
    } else {
        alert("Wrong admin credentials.");
    }
}

function renderLogs() {
    const logDiv = document.getElementById("logData");
    logDiv.innerHTML = "";

    demoLogs.forEach((log, index) => {
        logDiv.innerHTML += `
            <p>#${index + 1} | ${log.method} | ${log.value} | ${log.time}</p>
        `;
    });
}
